<?php

Class Bird { 
    
    public $commonName; 
    public $latinName; 
    public function __construct($args=[]) { 
        $this->commonName = $args['commonName'] ?? NULL;
        $this->latinName = $args['latinName'] ?? NULL; 
    }
    
}

?>
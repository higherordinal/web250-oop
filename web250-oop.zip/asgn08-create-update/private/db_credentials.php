<?php

// Keep database credentials in a separate file
// 1. Easy to exclude this file from source code managers
// 2. Unique credentials on development and production servers
// 3. Unique credentials if working with multiple developers

// localhost
// define("DB_SERVER", "localhost");
// define("DB_USER", "sabirdsUser");
// define("DB_PASS", "cassowary");
// define("DB_NAME", "sabirds");

// bluehost
define("DB_SERVER", "50.6.152.227");
define("DB_USER", "swbhdnmy_sabirdsUser");
define("DB_PASS", "!QRDF7B@7K)3");
define("DB_NAME", "swbhdnmy_sabirds");

?>
